# config.py

# Bot token obtained from Discord Developer Portal
BOT_TOKEN = 'your_bot_token_here'

# Channel IDs
WELCOME_CHANNEL_ID = 123456789012345678  # Replace with your actual welcome channel ID
LEAVE_CHANNEL_ID = 123456789012345678   # Replace with your actual leave channel ID
LOG_CHANNEL_ID = 123456789012345678     # Replace with your actual log channel ID

# Embed color (hexadecimal)
EMBED_COLOR = 0xabcdef  # Replace with your desired embed color code

OWNER_ID = 123456789012345678  # Replace with your actual owner's user ID
